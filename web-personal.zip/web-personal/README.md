# Página Web Personal
Página web personal desarrollada con HTML, CSS y PHP.

## Funcionalidades
- Información personal
- Calculadora básica en PHP

## Herramientas usadas
- Visual Studio Code
- XAMPP
- GitHub

## Autor
Michael Steven Castro Lema
