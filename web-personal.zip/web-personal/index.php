<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi Web Personal</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>

<div class="contenedor">

    <h1>Mi Página Web Personal</h1>

    <section class="info">
        <h2>Información Personal</h2>
        <p><strong>Nombre:</strong> Michael Steven Castro Lema</p>
        <p><strong>Carrera:</strong> Ingeniería en Software</p>
        <p><strong>Ciudad:</strong> Píllaro</p>
        <p><strong>Correo:</strong> michael52@example.com</p>
    </section>

    <section class="calculadora">
        <h2>Calculadora en PHP</h2>

        <form method="post">
            <input type="number" name="num1" placeholder="Número 1" required>
            <input type="number" name="num2" placeholder="Número 2" required>

            <select name="operacion">
                <option value="suma">Sumar</option>
                <option value="resta">Restar</option>
                <option value="multiplicacion">Multiplicar</option>
                <option value="division">Dividir</option>
            </select>

            <button type="submit">Calcular</button>
        </form>

        <?php
        if ($_POST) {
            $num1 = $_POST["num1"];
            $num2 = $_POST["num2"];
            $operacion = $_POST["operacion"];
            $resultado = 0;

            if ($operacion == "suma") {
                $resultado = $num1 + $num2;
            } elseif ($operacion == "resta") {
                $resultado = $num1 - $num2;
            } elseif ($operacion == "multiplicacion") {
                $resultado = $num1 * $num2;
            } elseif ($operacion == "division") {
                if ($num2 != 0) {
                    $resultado = $num1 / $num2;
                } else {
                    echo "<p class='error'>No se puede dividir entre cero</p>";
                }
            }

            echo "<p class='resultado'>Resultado: $resultado</p>";
        }
        ?>
    </section>

</div>

</body>
</html>
